import {config} from 'dotenv';
config({path:'.env.local'});config();
import mysql from 'mysql2/promise';
import {repairQuizSubject} from './schema-repair.js';
const database=process.env.DB_NAME||'examlan';
if(!/^[a-z0-9_]+$/i.test(database))throw new Error('Nama database tidak sah');
const connection=await mysql.createConnection({
  host:process.env.DB_HOST||'127.0.0.1',
  port:Number(process.env.DB_PORT||3306),
  user:process.env.DB_USER||'root',
  password:process.env.DB_PASSWORD||'',
  database,
  multipleStatements:false,
});
try{
  await repairQuizSubject(connection,database);
  console.log('Perbaikan skema selesai. Tidak ada tabel yang dihapus.');
}catch(error){console.error('Gagal memperbaiki skema:',error.message);process.exitCode=1;
}finally{await connection.end();}
