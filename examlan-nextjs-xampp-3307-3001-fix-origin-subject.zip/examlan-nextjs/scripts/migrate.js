import {config} from 'dotenv';
config({path:'.env.local'});config();
import mysql from 'mysql2/promise';
import {readdir,readFile} from 'node:fs/promises';
import {repairQuizSubject} from './schema-repair.js';
const connection=await mysql.createConnection({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',multipleStatements:false});
try{
 const name=process.env.DB_NAME||'examlan';if(!/^[a-z0-9_]+$/i.test(name))throw Error('Invalid database name');
 await connection.query(`CREATE DATABASE IF NOT EXISTS \`${name}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);await connection.query(`USE \`${name}\``);
 await connection.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(255) PRIMARY KEY,applied_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)) ENGINE=InnoDB`);
 const files=(await readdir('db/migrations')).filter(x=>x.endsWith('.sql')).sort();
 for(const file of files){const [applied]=await connection.execute('SELECT name FROM schema_migrations WHERE name=?',[file]);if(applied.length){console.log('SKIP',file);continue}const text=await readFile('db/migrations/'+file,'utf8');const statements=text.split(/;\s*(?:\r?\n|$)/).map(s=>s.trim()).filter(Boolean);
  for(const statement of statements){const sql=statement.replace(/(^|\n)\s*--[^\n]*/g,'\n').trim();if(sql&&!/^CREATE DATABASE\b|^USE\b/i.test(sql))await connection.query(sql)}await connection.execute('INSERT INTO schema_migrations(name) VALUES(?)',[file]);console.log('OK',file);
 }
 await repairQuizSubject(connection,name);
 console.log('Database ExamLAN siap.');
}catch(err){console.error(err);process.exitCode=1}finally{await connection.end()}
