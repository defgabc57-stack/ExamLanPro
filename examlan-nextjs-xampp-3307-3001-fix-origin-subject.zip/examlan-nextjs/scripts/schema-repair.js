/** Idempotent targeted repair for databases created before subject existed. */
export async function repairQuizSubject(connection,database){
  const [tables]=await connection.execute(
    'SELECT COUNT(*) AS total FROM information_schema.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?',
    [database,'quizzes']
  );
  if(!Number(tables[0]?.total))throw new Error('Tabel quizzes belum ada. Jalankan npm run db:init terlebih dahulu.');
  const [columns]=await connection.execute(
    'SELECT COUNT(*) AS total FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND COLUMN_NAME=?',
    [database,'quizzes','subject']
  );
  if(Number(columns[0]?.total)){
    console.log('SKIP perbaikan: quizzes.subject sudah tersedia.');
    return {changed:false};
  }
  await connection.query('ALTER TABLE `quizzes` ADD COLUMN `subject` VARCHAR(150) NULL AFTER `description`');
  console.log('OK perbaikan: kolom quizzes.subject ditambahkan, data lama dipertahankan.');
  return {changed:true};
}
